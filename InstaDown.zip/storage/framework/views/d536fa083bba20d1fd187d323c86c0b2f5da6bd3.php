<?php $__env->startSection('section'); ?>
<section>
    <div class="container ">
      <div class="content">
        
        <div class="info_block text_block">
          <h4 class="info_block_title">About us</h4>
          <p class="info_desc">Download Instagram videos and photos without registration, completely free and fast, works on pc and mobile phones. 
  The service is easy to use, you only need to paste an Instagram video or photo URL and click on the download button, that’s all! 
  Enjoy.</p>
        
        </div>    
      </div>
  
    </div>  
  </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\Training\InstaDown\resources\views/about.blade.php */ ?>